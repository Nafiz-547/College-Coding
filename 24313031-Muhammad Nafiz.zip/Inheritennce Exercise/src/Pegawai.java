public class Pegawai {
    protected String nama;
    protected String idPegawai;
    protected double gajiDasar;
    
    public Pegawai(String nama, String idPegawai, double gajiDasar){
        this.nama = nama;
        this.idPegawai = idPegawai;
        this.gajiDasar = gajiDasar;
    }
    
    public double hitungGaji(){
        return gajiDasar;
    }
    
    public void tampilkanInfo(){
        System.out.println ("Nama Pegawai: " + this.nama);
        System.out.println ("ID Pegawai: " + this.idPegawai);
        System.out.println ("Gaji Dasar: " + this.gajiDasar);
    }
}
