public class PegawaiTetap extends Pegawai {
    private double tunjangan;

    public PegawaiTetap(String nama, String idPegawai, double gajiDasar, double tunjangan) {
        super(nama, idPegawai, gajiDasar);
        this.tunjangan = tunjangan;
    }
    
    public double hitungGaji(){
        return this.gajiDasar + this.tunjangan;
    }
    
    public void tampilkanInfo(){
        System.out.println ("===== Pegawai Tetap =====");
        System.out.println ("Nama Pegawai: " + this.nama);
        System.out.println ("ID Pegawai: " + this.idPegawai);
        System.out.println ("Gaji Dasar: " + this.gajiDasar);
        System.out.println ("Tunjangan: " + this.tunjangan);
        System.out.println ("Total Gaji Pegawai Tetap: " + hitungGaji());
    }
    
}
