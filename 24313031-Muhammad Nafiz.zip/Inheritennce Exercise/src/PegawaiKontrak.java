public class PegawaiKontrak extends Pegawai{
    private int hariKerja;
    private double upahPerHari;
    
    public PegawaiKontrak(String nama, String idPegawai, int hariKerja, double upahPerHari) {
        super(nama, idPegawai, 0);
        this.hariKerja = hariKerja;
        this.upahPerHari = upahPerHari;
    }
    
    public double hitungGaji(){
        return this.hariKerja * this.upahPerHari;
    }
    
    public void tampilkanInfo(){
        System.out.println ("===== Pegawai Kontrak =====");
        System.out.println ("Nama Pegawai: " + this.nama);
        System.out.println ("ID Pegawai: " + this.idPegawai);
        System.out.println ("Hari Kerja: " + this.hariKerja);
        System.out.println ("Upah PerHari: " + this.upahPerHari);
        System.out.println ("Total Gaji Pegawai Kontrak: " + hitungGaji());
    }
    
}
