
import java.util.ArrayList;


public class Divisi {
    private String namaDivisi;
    private ArrayList<Pegawai> daftarPegawai;
    
    public Divisi (String namaDivisi){
        this.namaDivisi = namaDivisi;
        this.daftarPegawai = new ArrayList<>();
    }
    
    public void tambahPegawai (Pegawai p){
        daftarPegawai.add(p);
    }
    
    public void tampilkanSemuaPegawai() {
        System.out.println("=== Divisi: " + namaDivisi + " ===");
        double totalGaji = 0;

        for (Pegawai p : daftarPegawai) {
            p.tampilkanInfo();
            System.out.println("----------------------");
            totalGaji += p.hitungGaji();
        }

        System.out.println("Total Gaji Divisi: " + totalGaji);
    }
}


