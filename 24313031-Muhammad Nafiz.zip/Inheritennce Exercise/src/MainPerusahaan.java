public class MainPerusahaan {
    public static void main(String[] args) {
        // Membuat divisi-divisi
        Divisi divIT = new Divisi("IT");
        Divisi divHR = new Divisi("HR");

        // Membuat objek PegawaiTetap
        PegawaiTetap pt1 = new PegawaiTetap("Rina", "PT001", 5000000, 1500000);
        PegawaiTetap pt2 = new PegawaiTetap("Dewi", "PT002", 5500000, 1200000);

        // Membuat objek PegawaiKontrak
        PegawaiKontrak pk1 = new PegawaiKontrak("Budi", "PK001", 22, 200000);
        PegawaiKontrak pk2 = new PegawaiKontrak("Andi", "PK002", 18, 180000);

        // Menambahkan pegawai ke divisi
        divIT.tambahPegawai(pt1);
        divIT.tambahPegawai(pk1);

        divHR.tambahPegawai(pt2);
        divHR.tambahPegawai(pk2);

        // Menampilkan semua pegawai dan total gaji per divisi
        divIT.tampilkanSemuaPegawai();
        System.out.println();
        divHR.tampilkanSemuaPegawai();
    }
}
